# Campagne camp-ci-fixture -- FIXTURE

Archive fabriquee pour l integration continue. **Aucune donnee reelle.**

## Gardes de lecture

Regime d'execution `synthetic` : ces reponses ont ete fabriquees pour le banc et n'observent aucun operateur reel. `model_served_attestation` y vaut l'attestation de l'enregistrement rejoue, pas celle d'un fournisseur.

## Limites

- Un signal `null` signifie non mesure, jamais zero.
- Aucun operateur reel n a ete observe.
